from django.shortcuts import render
from .models import Article
 
 
def articleView(request):
    article_list=Article.objects.all()
    return render (request,'base/home.html',{'article_list':article_list})
